<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_9827d3df66ae8d506d0abc46ebc860b0'] = 'Blockgruppe oben';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_dc5ddf41afac839ace02f1d9c44531c9'] = 'Fügt einen Block hinzu, mit dem Kunden eine Sprache für Ihren Speicherinhalt auswählen können.';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_f38f5974cdc23279ffe6d203641a8bdf'] = 'Einstellungen aktualisiert.';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_27e86e8ba547905b1e374817add18330'] = 'Benutzerinformationen sperren';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_0105bbbc3f8d8fa1c91d26357e89d25b'] = 'Aktivieren / Deaktivieren von Benutzerinformationen.';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_b9f5c797ebbf55adccdd8539a65a0241'] = 'Behindert';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_c9cc8cce247e49bae79f15173ce97354'] = 'Sparen';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_51ac4bf63a0c6a9cefa7ba69b4154ef1'] = 'Rahmen';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_4994a8ffeba4ac3140beb89e8d41f174'] = 'Sprache';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_386c339d37e737a436499d423a77df0c'] = 'Währung';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_2cbfb6731610056e1d0aaacde07096c1'] = 'Mein Kundenkonto anzeigen';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_8b1a9953c4611296a827abf8c47804d7'] = 'Hallo';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_c87aacf5673fada1108c9f809d354311'] = 'Ausloggen';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_d4151a9a3959bdd43690735737034f27'] = 'Melden Sie sich bei Ihrem Kundenkonto an';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_b6d4223e60986fa4c9af77ee5f7149c5'] = 'Anmelden';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mein Konto';
$_MODULE['<{blockgrouptop}prestashop>blockgrouptop_6ff063fbc860a79759a7369ac32cee22'] = 'Auschecken';
